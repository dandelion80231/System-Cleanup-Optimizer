﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace CpqSystemTool
{
    public partial class MainWindow
    {
        // =====================================================================
        //  Module: 维护工具（含官方 exe 直链探针）
        // =====================================================================

        private UIElement BuildMaintenanceTools()
        {
            // root 不再单独加边距，统一沿用 ContentArea 的 Margin(22,12,22,22)，
            // 使顶部副标题高度与清理优化页一致、圆角卡片底部贴近窗口（与 Appx 管理页一致）。
            var root = new StackPanel { Margin = new Thickness(0) };

            // 顶部说明
            root.Children.Add(Header("", "维护工具：抓取官网软件安装包（exe）直链、管理本地探针依赖等。探针支持两种驱动：WebView2 Runtime（优先，复用系统 Edge，无需下载）或 Node + Playwright + Chromium（兜底）。点击「管理依赖」可分别安装/卸载两种环境。"));

            // ========== 探针卡片 ==========
            var probeCard = new Border
            {
                Background = _isDarkMode ? Brushes.Transparent : _bgCard,
                BorderBrush = _panelBorder,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(12),
                Padding = new Thickness(16),
                // 本卡片为页面最后一个元素，去掉底部外边距，使其贴近窗口底部（与 Appx 管理页一致）
                Margin = new Thickness(0)
            };
            var probeInner = new StackPanel();
            probeCard.Child = probeInner;

            probeInner.Children.Add(new TextBlock
            {
                Text = "官方 exe 直链探针",
                FontWeight = FontWeights.Bold,
                Foreground = _accent,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 8)
            });

            // 输入框（带占位符水印）
            var placeholder = "输入入口 URL 或厂商名（qq/qqmusic/douyin/...）";
            var inputBox = new TextBox
            {
                Text = placeholder,
                FontSize = 13,
                Padding = new Thickness(8, 6, 8, 6),
                Background = _isDarkMode ? Brushes.Transparent : _bgDeep,
                Foreground = _textDim,
                BorderBrush = _accent,
                BorderThickness = new Thickness(1),
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            bool inputTouched = false;
            inputBox.GotKeyboardFocus += (s, e) =>
            {
                if (!inputTouched) { inputBox.Text = ""; inputBox.Foreground = _textMain; inputTouched = true; }
            };
            inputBox.LostKeyboardFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(inputBox.Text))
                {
                    inputBox.Text = placeholder;
                    inputBox.Foreground = _textDim;
                    inputTouched = false;
                }
            };
            probeInner.Children.Add(inputBox);

            // 选项 + 按钮行（4 列均分占满整行：跳过检测 / 抓取直链 / 管理依赖 / 管理软件）
            var optRow = new Grid { HorizontalAlignment = HorizontalAlignment.Stretch, Margin = new Thickness(0, 10, 0, 0) };
            optRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            optRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            optRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            optRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var skipDlCheck = new CheckBox
            {
                Content = "跳过点击下载检测（更快）",
                Foreground = _textMain,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(skipDlCheck, 0);
            optRow.Children.Add(skipDlCheck);

            var fetchBtn = Btn("抓取直链", true, null, 120);
            fetchBtn.HorizontalAlignment = HorizontalAlignment.Center;
            Grid.SetColumn(fetchBtn, 1);
            optRow.Children.Add(fetchBtn);

            // 「管理依赖」按钮：带下拉菜单（ToggleButton + Popup），支持 Node / WebView2 两种方案的安装、卸载、清理。
            // 真实根因（已由 D:\电脑桌面\deps_diag.log 证实）：此前用 StaysOpen=false，弹窗打开后
            // RefreshDepStatus 触发的 WebView2 宿主（隐藏 WinForms Form）会抢占窗口激活，Light-Dismiss
            // 把这次激活误判为"外部点击"，在 ~110ms 内自动关闭弹窗 → 用户只见"点不开"。
            // catBtn 不闪，是因为它打开时从不调用任何会激活外部窗口的逻辑，并非模板差异。
            // 修复：Popup.StaysOpen = true（不再自动关闭），改由窗口级 PreviewMouseDown（点外部关闭）
            // 与菜单项点击（MakeMenuItem 已置 IsOpen=false）手动关闭。
            // 选中态填充：accent 更高不透明度，比 hover 更明显（仍与主题一致）
            var depsSelectedBrush = _isDarkMode
                ? new SolidColorBrush(Color.FromArgb(0x73, 0x16, 0xE0, 0xBD))  // #16E0BD @ ~45%
                : new SolidColorBrush(Color.FromArgb(0x8C, 0x08, 0x91, 0x82)); // #089182 @ ~55%
            var depsBtnTemplate = new ControlTemplate(typeof(ToggleButton));
            var depsBtnBd = new FrameworkElementFactory(typeof(Border), "Bd");
            depsBtnBd.SetBinding(Border.BackgroundProperty, new Binding { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent), Path = new PropertyPath(BackgroundProperty) });
            depsBtnBd.SetBinding(Border.BorderBrushProperty, new Binding { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent), Path = new PropertyPath(BorderBrushProperty) });
            depsBtnBd.SetBinding(Border.BorderThicknessProperty, new Binding { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent), Path = new PropertyPath(BorderThicknessProperty) });
            depsBtnBd.SetValue(Border.CornerRadiusProperty, new CornerRadius(6));
            depsBtnBd.SetBinding(Border.PaddingProperty, new Binding { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent), Path = new PropertyPath(PaddingProperty) });
            var depsBtnCp = new FrameworkElementFactory(typeof(ContentPresenter));
            depsBtnCp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            depsBtnCp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            depsBtnBd.AppendChild(depsBtnCp);
            depsBtnTemplate.VisualTree = depsBtnBd;
            var depsBtnHover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            depsBtnHover.Setters.Add(new Setter(Border.BackgroundProperty, new DynamicResourceExtension("ButtonHoverBrush"), "Bd"));
            var depsBtnChecked = new Trigger { Property = ToggleButton.IsCheckedProperty, Value = true };
            depsBtnChecked.Setters.Add(new Setter(Border.BackgroundProperty, depsSelectedBrush, "Bd"));
            depsBtnTemplate.Triggers.Add(depsBtnHover);
            depsBtnTemplate.Triggers.Add(depsBtnChecked);

            // 按钮内容：文字 + 右侧下拉箭头，与驱动清理页 ComboBox 及「全部分类」下拉按钮保持视觉一致
            var depsBtnText = new TextBlock { Text = "管理依赖", FontSize = 12, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Left };
            var depsBtnContent = UiShapes.MakeTextWithArrowGrid(depsBtnText, _textDim);

            var manageDepsBtn = new ToggleButton
            {
                Content = depsBtnContent,
                MinWidth = 100,
                MinHeight = 34,
                Padding = new Thickness(8, 7, 8, 7),
                Cursor = Cursors.Hand,
                FontSize = 12,
                FontWeight = FontWeights.Normal,
                Background = _btnSecondaryBg,
                Foreground = _btnSecondaryFg,
                BorderThickness = new Thickness(1),
                BorderBrush = _panelBorder,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Template = depsBtnTemplate
            };
            Grid.SetColumn(manageDepsBtn, 2);
            optRow.Children.Add(manageDepsBtn);

            var manageBtn = Btn("管理软件", false, null, 150);
            manageBtn.HorizontalAlignment = HorizontalAlignment.Center;
            // 同步事件处理器：异常会直接抛到 Dispatcher，net48 下即进程终止（表现为"点一下就闪退"）。
            // 构造对话框（XAML 解析 / 读取持久化列表）与 ShowDialog 都有可能失败，故整体包 try/catch，
            // 失败只落状态栏提示，绝不让异常逸出。
            manageBtn.Click += (s, e) =>
            {
                try
                {
                    var dlg = new CustomSoftwareManagerDialog(this);
                    dlg.Owner = this;
                    dlg.ShowDialog();
                    SetStatus("增补软件列表已更新；请到「常用软件」页点刷新查看（重启后依然保留）");
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    SetStatus("打开「管理软件」失败: " + ex.Message);
                }
            };
            Grid.SetColumn(manageBtn, 3);
            optRow.Children.Add(manageBtn);
            probeInner.Children.Add(optRow);

            // 日志区（声明提前：下方菜单事件需要引用 logBox；视觉顺序放到最下方）
            var logBox = MakeLogBox();
            logBox.Height = 120;                    // 固定高度，不随日志内容自动扩展（MakeLogBox 已启用滚动条）
            logBox.Foreground = _textMain;          // 深色/浅色模式下都保证足够对比度
            var logBorder = WrapLogBox(logBox);
            // 保持透明，不额外加填充；靠 _textMain 主题文字色保证可读
            logBorder.Background = Brushes.Transparent;

            // ========== 「管理依赖」下拉菜单 ==========
            // 完全使用 Popup + 自定义 Border/StackPanel/TextBlock 实现，不再用 WPF ContextMenu/MenuItem。
            // 原因：ContextMenu 默认模板左侧有固定图标槽/gutter，背景读系统色，深/浅色主题下会出现白色竖边（用户截图）。
            // 自定义面板所有背景、文字、边框、hover 色都来自当前主题笔刷，四周颜色完全一致。
            var depsPopup = new Popup
            {
                PlacementTarget = manageDepsBtn,
                Placement = PlacementMode.Bottom,
                HorizontalOffset = 0,
                VerticalOffset = 2,
                StaysOpen = true,   // 关键修复：手动管理关闭。StaysOpen=false 时 Light-Dismiss 会把打开弹窗触发的
                                    // WebView2 宿主窗体激活误判为"外部点击"而立即自关（诊断日志证实 Opened 后~110ms 即 Closed）。
                                    // 现在由窗口级 PreviewMouseDown（点外部关闭）与菜单项点击手动关闭。
                AllowsTransparency = true
            };
            var menuPanel = new StackPanel { Background = _windowBg };
            var menuBorder = new Border
            {
                Background = _windowBg,
                BorderBrush = _panelBorder,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(1),
                MinWidth = 205,
                Child = menuPanel
            };
            depsPopup.Child = menuBorder;
            // 修复：AllowsTransparency=true 会让 Popup 以独立顶层 HWND 承载并带 WS_EX_TOPMOST，
            // 导致下拉菜单浮到最顶层、压在所有窗口之上。剥离该样式使其落到正常层级。
            UiShapes.DisablePopupTopmost(depsPopup);

            var nodeHeader = MakeMenuHeader("Node + Playwright + Chromium（检测中…）");
            var nodeInstall = MakeMenuItem("安装 / 修复", depsPopup, () =>
            {
                RunInBg(logBox, logf =>
                {
                    var probesDir = ResolveProbesDir();
                    var installPs = Path.Combine(probesDir, "install_deps.ps1");
                    if (!File.Exists(installPs))
                    {
                        logf("[!] 找不到 install_deps.ps1（目录：" + probesDir + "）");
                        return;
                    }
                    logf("[*] 开始安装/修复 Node + Playwright + Chromium 依赖……");
                    // 安装脚本失败时以 exit 1 退出；必须校验脚本退出码 + 重新校验 Node 与 Playwright 目录，
                    // 否则会出现“安装失败却报成功”的误判（此前踩过的坑）。
                    bool ok = RunPowerShellScript(probesDir, installPs, logf);
                    var dep = IsNodeDepsReady(probesDir);
                    if (ok && dep.Ready)
                        logf("[✓] Node 依赖安装完成（Node + Playwright 就绪）。");
                    else
                    {
                        logf("[!] Node 依赖安装未完成（脚本退出码=" + (ok ? "0" : "非零") +
                             "，Node=" + (dep.NodeExe != null ? "就绪" : "缺失") +
                             "，Playwright=" + (dep.PlaywrightExists ? "就绪" : "缺失") + "）。");
                        logf("    请检查网络后重试，或手动在 probes 目录运行 install_deps.ps1。");
                    }
                }, "依赖安装结束", null);
            });
            var nodeUninstall = MakeMenuItem("卸载本地依赖", depsPopup, () =>
            {
                var confirm = MessageBox.Show(
                    "确定要卸载本地 Node 依赖吗？\n\n将删除以下目录：\n" +
                    "- tools/probes/.tools\n" +
                    "- tools/probes/node_modules\n\n" +
                    "系统 PATH 中的 Node（如有）不会受影响。",
                    "卸载 Node 依赖", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (confirm != MessageBoxResult.Yes) return;
                RunInBg(logBox, logf =>
                {
                    var probesDir = ResolveProbesDir();
                    if (probesDir == null)
                    {
                        logf("[!] 未找到 probes 目录");
                        return;
                    }
                    var dirs = new[] { Path.Combine(probesDir, ".tools"), Path.Combine(probesDir, "node_modules") };
                    foreach (var d in dirs)
                    {
                        try
                        {
                            if (Directory.Exists(d))
                            {
                                Directory.Delete(d, true);
                                logf("[✓] 已删除：" + d);
                            }
                            else logf("[*] 目录不存在，跳过：" + d);
                        }
                        catch (Exception ex) { logf("[!] 删除失败：" + d + " — " + ex.Message); }
                    }
                    logf("[✓] Node 本地依赖卸载完成。");
                }, "卸载完成", null);
            });
            var wvHeader = MakeMenuHeader("WebView2 Runtime（系统 Edge）（检测中…）");
            var wvInstall = MakeMenuItem("安装 / 升级 / 修复", depsPopup, () =>
            {
                // RepairWebView2 会下载官方引导程序执行静默安装；若引导程序 no-op 则扫描磁盘并修复注册表指针。
                RunInBg(logBox, EdgeCore.RepairWebView2, "WebView2 修复完成", null);
            });
            var wvUninstall = MakeMenuItem("卸载", depsPopup, () =>
            {
                var confirm = MessageBox.Show(
                    "WebView2 Runtime 是系统级组件，Edge 和部分应用可能依赖它。\n\n" +
                    "确定要继续卸载吗？卸载后可能导致依赖 WebView2 的程序无法运行。",
                    "卸载 WebView2 Runtime", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (confirm != MessageBoxResult.Yes) return;
                RunInBg(logBox, EdgeCore.UninstallWebView2, "WebView2 卸载完成", null);
            });
            var wvClean = MakeMenuItem("清理探针缓存", depsPopup, () =>
            {
                RunInBg(logBox, logf =>
                {
                    var tmpRoot = Path.GetTempPath();
                    try
                    {
                        int cleaned = 0;
                        foreach (var d in Directory.GetDirectories(tmpRoot, "CpqProbeWebView2*"))
                        {
                            try { Directory.Delete(d, true); cleaned++; }
                            catch (Exception ex) { logf("[!] 清理失败：" + d + " — " + ex.Message); }
                        }
                        if (cleaned > 0) logf("[✓] 已清理 " + cleaned + " 个探针缓存目录。");
                        else logf("[*] 未发现探针缓存目录。");
                    }
                    catch (Exception ex) { logf("[!] 清理失败：" + ex.Message); }
                }, "缓存清理完成", null);
            });

            menuPanel.Children.Add(nodeHeader);
            menuPanel.Children.Add(nodeInstall);
            menuPanel.Children.Add(nodeUninstall);
            menuPanel.Children.Add(MakeMenuSeparator());
            menuPanel.Children.Add(wvHeader);
            menuPanel.Children.Add(wvInstall);
            menuPanel.Children.Add(wvUninstall);
            menuPanel.Children.Add(wvClean);

            // 拖动主窗口时强制 popup 重新定位到按钮下方：
            // popup 以独立 HWND（AllowsTransparency=true）承载，默认不跟随窗口移动（标题栏是非客户区，
            // 也不触发下方 PreviewMouseDown 的关闭逻辑），故需在窗口位置变化时手动重定位。
            // 通过微调 HorizontalOffset 触发 WPF 重新按 PlacementTarget 计算屏幕位置，归零后无可见抖动。
            EventHandler repositionDepsPopup = (s, e) =>
            {
                if (!depsPopup.IsOpen) return;
                var dx = depsPopup.HorizontalOffset;
                depsPopup.HorizontalOffset = dx + 0.01;
                depsPopup.HorizontalOffset = dx;
            };

            // 与 MainWindow.Pages.cs 里分类下拉 catBtn 完全一致的稳定写法：
            // 在 Click 事件里【同步】切换 IsOpen（不延迟），并用 Opened/Closed 同步 ToggleButton 的 IsChecked。
            // 打开的同时刷新依赖状态（Node 就绪 / WebView2 就绪）。
            // 注：此前"点不开"与 ControlTemplate 无关，根因是 StaysOpen=false 的 Light-Dismiss 自关（见上方说明）。
            manageDepsBtn.Click += (s, e) =>
            {
                depsPopup.IsOpen = !depsPopup.IsOpen;
                if (depsPopup.IsOpen) { var _ = RefreshDepStatus(nodeHeader, wvHeader, logBox); }
            };
            depsPopup.Opened += (s, e) =>
            {
                manageDepsBtn.IsChecked = true;
                depsPopup.Width = Math.Max(manageDepsBtn.ActualWidth, 205);
                this.LocationChanged += repositionDepsPopup;
            };
            depsPopup.Closed += (s, e) =>
            {
                manageDepsBtn.IsChecked = false;
                this.LocationChanged -= repositionDepsPopup;
            };

            // 手动管理"点击弹窗外部关闭"：StaysOpen=true 后不再自动关闭，需自行处理。
            // 点在按钮本身或弹窗内容内 → 不关闭（按钮 Click 负责切换；弹窗内点击由各项自关）。
            // 修复：这是窗口级事件，此前只 += 从不 -= —— 每次重建维护页都会在窗口上多挂一个闭包，
            // 旧闭包连同整页控件一起常驻（事件泄漏），且多个处理器会重复执行同一逻辑。
            // 改为具名处理器 + 页面根 root 卸载时（导航切走 / 主题重建页面）自动解绑。
            MouseButtonEventHandler closeDepsOnOutsideClick = (s, e) =>
            {
                // 这是窗口级处理器，一旦抛异常就是 net48 的进程级崩溃，故整体兜底；
                // 兜底失败也只当作"这次点击没关掉弹窗"，不影响其它交互。
                try
                {
                    if (!depsPopup.IsOpen) return;
                    var cur = e.OriginalSource as DependencyObject;
                    while (cur != null)
                    {
                        if (ReferenceEquals(cur, manageDepsBtn) || ReferenceEquals(cur, menuBorder) || ReferenceEquals(cur, menuPanel))
                            return;
                        // ↑ VisualTreeHelper.GetParent 遇到 Inline（Run / Hyperlink 等非 Visual）会抛异常，
                        //   所以整段必须包在 try 里——点中 TextBlock 内嵌的 Run 时 OriginalSource 可能就是它。
                        cur = VisualTreeHelper.GetParent(cur) as DependencyObject
                              ?? LogicalTreeHelper.GetParent(cur) as DependencyObject;
                    }
                    depsPopup.IsOpen = false;
                }
                catch (Exception ex) { DebugLog.Ignore(ex); }
            };

            // 挂/解绑与页面生命周期对齐：只在页面真正卸载（导航切走 / 主题重建页面 / 窗口关闭）时解绑，
            // 杜绝旧写法"只 += 从不 -="造成的闭包与整页控件常驻泄漏。
            //
            // ★ 为什么不只靠 Unloaded 解绑：FrameworkElement.Unloaded 并不等价于"这个页面被丢弃了"。
            //   除了元素被移出可视化树，它还会因为「元素所属子树与 PresentationSource 断开」而触发，
            //   典型场景包括：控件模板被重新应用、元素被临时摘下又挂回（TabControl 换页、
            //   VirtualizingStackPanel 回收、父容器 Content 被置空再设回）等。若发生这种"误触发"，
            //   只解绑不重绑的写法会把处理器永久摘掉 —— 而本弹窗 StaysOpen=true 且已不再有
            //   Light-Dismiss 兜底，结果就是"点外部再也关不掉弹窗"，正是此前反复修的那类问题。
            //   本页 root 目前是 ScrollViewer 的直接 Content（无虚拟化、无 TabControl），
            //   实际不会误触发；但 Loaded 重绑成本为零，且让这段逻辑将来被搬到任何容器里都成立。
            //
            // 两处都先 -= 再 +=（幂等）：即使 Loaded 被多次触发也不会在窗口上累积重复处理器，
            // 因此反复切换主题（页面反复重建）不会让 this.PreviewMouseDown 越挂越多。
            RoutedEventHandler attachOutsideClickHook = null;
            RoutedEventHandler detachOutsideClickHook = null;
            attachOutsideClickHook = (s, e) =>
            {
                this.PreviewMouseDown -= closeDepsOnOutsideClick;
                this.PreviewMouseDown += closeDepsOnOutsideClick;
            };
            detachOutsideClickHook = (s, e) =>
            {
                this.PreviewMouseDown -= closeDepsOnOutsideClick;
                // 页面已被卸载（导航切走/主题重建/窗口关闭），弹窗也一并收起，避免留下无主的浮层
                try { depsPopup.IsOpen = false; }
                catch (Exception ex) { DebugLog.Ignore(ex); }
            };
            // 先立即挂上：即使 Loaded 因故未触发，也退化为旧行为（始终挂着），比"永不生效"更稳。
            attachOutsideClickHook(null, null);
            root.Loaded += attachOutsideClickHook;
            root.Unloaded += detachOutsideClickHook;

            // 推荐直链区
            probeInner.Children.Add(new TextBlock
            {
                Text = "推荐直链：",
                FontWeight = FontWeights.Bold,
                Foreground = _textMain,
                Margin = new Thickness(0, 12, 0, 4)
            });
            var recDock = new DockPanel();
            var copyRecBtn = Btn("复制推荐链接", false, null, 130);
            copyRecBtn.IsEnabled = false;
            DockPanel.SetDock(copyRecBtn, Dock.Right);
            recDock.Children.Add(copyRecBtn);
            var recommendedTb = new TextBox
            {
                IsReadOnly = true,
                FontSize = 12,
                Padding = new Thickness(8, 6, 8, 6),
                Background = _isDarkMode ? Brushes.Transparent : _bgDeep,
                Foreground = _textMain,
                BorderBrush = _accent,
                BorderThickness = new Thickness(1),
                VerticalContentAlignment = VerticalAlignment.Center
            };
            recDock.Children.Add(recommendedTb);
            probeInner.Children.Add(recDock);

            // 搜索定位提示：当推荐直链由搜索引擎（而非内置别名/URL 直抓）得到时显示，提醒人工核对
            var searchWarnTb = new TextBlock
            {
                Text = "（部分结果由搜索引擎定位且不在官方域名下，已标「⚠ 需核对」；复制/加入常用前需二次确认，谨防仿冒安装包）",
                Foreground = _warnOrange,
                FontSize = 11,
                Margin = new Thickness(0, 4, 0, 0),
                Visibility = Visibility.Collapsed
            };
            probeInner.Children.Add(searchWarnTb);

            // 结果面板（DataGrid）：标题与提示说明放在同一行
            var candidateHeader = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 4) };
            candidateHeader.Children.Add(new TextBlock
            {
                Text = "候选直链：",
                FontWeight = FontWeights.Bold,
                Foreground = _textMain
            });
            candidateHeader.Children.Add(new TextBlock
            {
                Text = "从下方候选直链点「加入」可直接增补，或点上方「管理软件」统一管理。",
                Foreground = _textDim,
                FontSize = 11,
                Margin = new Thickness(8, 2, 0, 0)
            });
            probeInner.Children.Add(candidateHeader);
            var dg = new DataGrid
            {
                AutoGenerateColumns = false,
                IsReadOnly = true,
                // 保持透明，不额外加填充；行/单元格/列头各自透明，网格线用主题边框色
                Background = Brushes.Transparent,
                Foreground = _textMain,
                BorderBrush = _panelBorder,
                BorderThickness = new Thickness(1),
                Margin = new Thickness(0, 4, 0, 0),
                MaxHeight = 360,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                RowBackground = Brushes.Transparent,
                AlternatingRowBackground = Brushes.Transparent,
                HeadersVisibility = DataGridHeadersVisibility.Column,
                GridLinesVisibility = DataGridGridLinesVisibility.Horizontal,
                HorizontalGridLinesBrush = _panelBorder
            };
            // 列头透明底 + 主题文字色，避免默认系统色在深色模式下发灰/发白。
            // 去重：原先此处内联造样式，与同文件 MakeDataGridStyles 重复且少 2 个属性
            // （列头缺 HorizontalContentAlignment/Padding、单元格缺 Padding），
            // 导致本页网格与驱动管理页外观不一致；改为复用 MakeDataGridStyles 统一外观。
            var dgStyles = MakeDataGridStyles(_textMain, _panelBorder);
            dg.ColumnHeaderStyle = dgStyles.Header;
            dg.CellStyle = dgStyles.Cell;
            dg.Columns.Add(new DataGridTextColumn { Header = "来源", Binding = new Binding("Source"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
            dg.Columns.Add(new DataGridTextColumn { Header = "URL", Binding = new Binding("Url"), Width = new DataGridLength(3, DataGridLengthUnitType.Star) });
            dg.Columns.Add(new DataGridTextColumn { Header = "策略", Binding = new Binding("Strategy"), Width = new DataGridLength(90) });
            dg.Columns.Add(new DataGridTextColumn { Header = "架构", Binding = new Binding("Arch"), Width = new DataGridLength(60) });
            dg.Columns.Add(new DataGridTextColumn { Header = "验证", Binding = new Binding("VerifiedText"), Width = new DataGridLength(90) });
            dg.Columns.Add(new DataGridTextColumn { Header = "HTTP状态", Binding = new Binding("StatusText"), Width = new DataGridLength(80) });
            dg.Columns.Add(new DataGridTextColumn { Header = "Content-Type", Binding = new Binding("ContentType"), Width = new DataGridLength(160) });
            dg.Columns.Add(new DataGridTextColumn { Header = "推荐", Binding = new Binding("RecMark"), Width = new DataGridLength(45) });
            dg.Columns.Add(new DataGridTextColumn { Header = "信任", Binding = new Binding("TrustText"), Width = new DataGridLength(70) });

            // 每行的「复制」按钮（用 FrameworkElementFactory 构建模板列）
            var copyCol = new DataGridTemplateColumn { Header = "复制", Width = new DataGridLength(56) };
            var factory = new FrameworkElementFactory(typeof(Button));
            factory.SetValue(Button.ContentProperty, "复制");
            factory.SetValue(Button.WidthProperty, 46.0);
            factory.SetValue(Button.FontSizeProperty, 11.0);
            factory.SetValue(Button.CursorProperty, Cursors.Hand);
            // 修复：async void 处理器里未被捕获的异常会直接抛到 Dispatcher，net48 下触发进程级崩溃。
            // 故把全部异步逻辑包进 try/catch，失败只落状态栏提示，绝不逃逸。
            factory.AddHandler(Button.ClickEvent, new RoutedEventHandler(async (s, ev) =>
            {
                var btn = s as Button;
                try
                {
                    var row = btn?.DataContext as ProbeCandidateRow;
                    if (row == null || string.IsNullOrEmpty(row.Url)) return;
                    // 低信任（搜索来源且非官方域名）候选：复制前强制二次确认，防仿冒安装包
                    if (row.LowTrust)
                    {
                        var confirm = MessageBox.Show(
                            "该直链由搜索引擎定位，且不在官网域名下，可能为仿冒安装包。\n\n" + row.Url + "\n\n确认仍要复制此链接吗？",
                            "域名待核对 · 安全风险", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (confirm != MessageBoxResult.Yes) return;
                    }
                    btn.IsEnabled = false;
                    try
                    {
                        if (await TrySetClipboardTextAsync(row.Url))
                            SetStatus("已复制: " + row.Url);
                        else
                            SetStatus("复制失败: 剪贴板被占用，请稍后重试");
                    }
                    finally { btn.IsEnabled = true; }
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    try
                    {
                        if (btn != null) btn.IsEnabled = true;
                        SetStatus("复制失败: " + ex.Message);
                    }
                    catch { /* 窗口已关闭，忽略 */ }
                }
            }));
            copyCol.CellTemplate = new DataTemplate { VisualTree = factory };
            dg.Columns.Add(copyCol);

            // 每行的「加入常用」按钮：把候选直链预填进编辑对话框，保存即写入自定义软件列表（与「常用软件」页联动）
            var addCol = new DataGridTemplateColumn { Header = "加入常用", Width = new DataGridLength(70) };
            var addFactory = new FrameworkElementFactory(typeof(Button));
            addFactory.SetValue(Button.ContentProperty, "加入");
            addFactory.SetValue(Button.WidthProperty, 56.0);
            addFactory.SetValue(Button.FontSizeProperty, 11.0);
            addFactory.SetValue(Button.PaddingProperty, new Thickness(6, 3, 6, 3));
            addFactory.SetValue(Button.CursorProperty, Cursors.Hand);
            addFactory.SetValue(Button.BackgroundProperty, _btnSecondaryBg);
            addFactory.SetValue(Button.ForegroundProperty, _btnSecondaryFg);
            addFactory.SetValue(Button.BorderThicknessProperty, new Thickness(1));
            addFactory.SetValue(Button.BorderBrushProperty, _panelBorder);
            // 同步事件处理器：MessageBox.Show / 对话框构造（XAML 解析）/ ShowDialog 都可能抛，
            // 未捕获会直接抛到 Dispatcher —— net48 下即进程终止。故整体包 try/catch，
            // 失败只落状态栏提示（原先只有最内层 AddOrUpdate 有保护，前面的弹窗环节是裸奔的）。
            addFactory.AddHandler(Button.ClickEvent, new RoutedEventHandler((s, ev) =>
            {
                try
                {
                    var btn = s as Button;
                    var row = btn?.DataContext as ProbeCandidateRow;
                    if (row == null || string.IsNullOrEmpty(row.Url)) { SetStatus("该行无可用直链，无法加入常用软件"); return; }
                    // 低信任候选：加入常用软件前强制二次确认，避免把仿冒直链固化进常用列表
                    if (row.LowTrust)
                    {
                        var confirm = MessageBox.Show(
                            "该直链由搜索引擎定位，且不在官网域名下，可能为仿冒安装包。\n\n" + row.Url + "\n\n确认仍要将其加入常用软件吗？",
                            "域名待核对 · 安全风险", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (confirm != MessageBoxResult.Yes) return;
                    }
                    var dlg = new CustomSoftwareEditDialog(this, null, row.Url, row.Source);
                    dlg.Owner = this;
                    if (dlg.ShowDialog() == true && dlg.Entry != null)
                    {
                        try
                        {
                            SoftwareDefPersistence.AddOrUpdate(dlg.Entry);
                            SetStatus("已加入增补软件: " + (dlg.Entry.name ?? dlg.Entry.id));
                        }
                        catch (Exception ex)
                        {
                            DebugLog.Ignore(ex);
                            SetStatus("保存失败: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    try { SetStatus("加入常用软件失败: " + ex.Message); }
                    catch { /* 窗口已关闭，忽略 */ }
                }
            }));
            addCol.CellTemplate = new DataTemplate { VisualTree = addFactory };
            dg.Columns.Add(addCol);

            // 推荐行高亮（用 RowStyle + DataTrigger，避免仅依赖颜色表意）
            var rowStyle = new Style(typeof(DataGridRow));
            var recTrig = new DataTrigger { Binding = new Binding("IsRecommended"), Value = true };
            recTrig.Setters.Add(new Setter(DataGridRow.BackgroundProperty, _accent));
            recTrig.Setters.Add(new Setter(DataGridRow.ForegroundProperty, Brushes.Black));
            rowStyle.Triggers.Add(recTrig);
            // 低信任行（搜索来源且非官方域名）：橙色文字提醒人工核对，与推荐高亮互斥（推荐已排除 lowTrust）
            var lowTrig = new DataTrigger { Binding = new Binding("LowTrust"), Value = true };
            lowTrig.Setters.Add(new Setter(DataGridRow.ForegroundProperty, _warnOrange));
            rowStyle.Triggers.Add(lowTrig);
            dg.RowStyle = rowStyle;

            probeInner.Children.Add(dg);

            // 日志区放到最下方，与其他页面「日志框在底部」的布局统一
            probeInner.Children.Add(new TextBlock
            {
                Text = "运行日志：",
                FontWeight = FontWeights.Bold,
                Foreground = _textMain,
                Margin = new Thickness(0, 12, 0, 4)
            });
            probeInner.Children.Add(logBorder);

            root.Children.Add(probeCard);

            // ========== 按钮事件 ==========

            // 「抓取直链」：后台运行探针，UI 不卡死
            fetchBtn.Click += (s, e) =>
            {
                // 同步处理器：一旦在进入后台任务前抛异常（例如 RunInBg 首次 Dispatcher.Invoke 时窗口已关停），
                // 按钮会永久卡在"抓取中..."且 IsEnabled=false。故整体包 try/catch，
                // catch 里保证把按钮恢复成可点状态，避免"点了一次之后再也点不动"。
                try
                {
                    var input = inputBox.Text.Trim();
                    if (!inputTouched || input == placeholder)
                    {
                        SetStatus("请输入入口 URL 或厂商名");
                        return;
                    }
                    fetchBtn.IsEnabled = false;
                    fetchBtn.Content = "抓取中...";
                    bool skip = skipDlCheck.IsChecked == true;

                    bool searchLocated = false;
                    RunInBg(logBox, logf =>
                    {
                        try
                        {
                            RunProbeInternal(input, skip, logf, out var rows, out var rec, out searchLocated);
                            _probeRows = rows;
                            _probeRecommendedUrl = rec;
                        }
                        catch (Exception ex)
                        {
                            logf("[!] 运行异常: " + ex.Message);
                        }
                    }, "抓取完成", () =>
                    {
                        // 后台任务无论成功失败都会回到这里（RunInBg 的两条路径都会调 onDoneUi）,
                        // 先无条件恢复按钮，再做结果填充——避免结果填充报错时按钮卡在"抓取中..."。
                        fetchBtn.IsEnabled = true;
                        fetchBtn.Content = "抓取直链";
                        try
                        {
                            recommendedTb.Text = _probeRecommendedUrl ?? "";
                            copyRecBtn.IsEnabled = !string.IsNullOrEmpty(_probeRecommendedUrl);
                            dg.ItemsSource = null;
                            dg.ItemsSource = _probeRows;
                            searchWarnTb.Visibility = searchLocated ? Visibility.Visible : Visibility.Collapsed;
                            SetStatus("抓取完成：共 " + (_probeRows?.Count ?? 0) + " 个候选" + (string.IsNullOrEmpty(_probeRecommendedUrl) ? "" : "，已推荐直链"));
                        }
                        catch (Exception ex)
                        {
                            DebugLog.Ignore(ex);
                            SetStatus("结果填充失败: " + ex.Message);
                        }
                    });
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    // 关键：进入后台任务失败时也必须把按钮放回可点状态，否则用户再也点不动。
                    try
                    {
                        fetchBtn.IsEnabled = true;
                        fetchBtn.Content = "抓取直链";
                        SetStatus("启动抓取失败: " + ex.Message);
                    }
                    catch { /* 窗口已关闭，忽略 */ }
                }
            };

            // 「复制推荐链接」
            // 同上的 async void 崩溃防护：补 catch，异常不逃逸到 Dispatcher。
            copyRecBtn.Click += async (s, e) =>
            {
                try
                {
                    if (string.IsNullOrEmpty(recommendedTb.Text)) return;
                    copyRecBtn.IsEnabled = false;
                    try
                    {
                        if (await TrySetClipboardTextAsync(recommendedTb.Text))
                            SetStatus("已复制推荐直链");
                        else
                            SetStatus("复制失败: 剪贴板被占用，请稍后重试");
                    }
                    finally { copyRecBtn.IsEnabled = true; }
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    try
                    {
                        copyRecBtn.IsEnabled = true;
                        SetStatus("复制失败: " + ex.Message);
                    }
                    catch { /* 窗口已关闭，忽略 */ }
                }
            };

            return root;
        }

        /// <summary>
        /// 构造 DataGrid 列头/单元格的通用主题样式（透明底 + 主题前景色 + 边框），
        /// 供维护页与驱动管理页等需要透明网格的页面复用，避免样式代码散落重复。
        /// 列头样式：透明底、主题文字色 fg、边框色 border；单元格样式：透明底、前景 fg、透明边框。
        /// </summary>
        internal static (Style Header, Style Cell) MakeDataGridStyles(Brush fg, Brush border)
        {
            var h = new Style(typeof(DataGridColumnHeader));
            h.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
            h.Setters.Add(new Setter(Control.ForegroundProperty, fg));
            h.Setters.Add(new Setter(Control.BorderBrushProperty, border));
            h.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Left));
            h.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(6, 3, 6, 3)));

            var c = new Style(typeof(DataGridCell));
            c.Setters.Add(new Setter(DataGridCell.BackgroundProperty, Brushes.Transparent));
            c.Setters.Add(new Setter(DataGridCell.ForegroundProperty, fg));
            c.Setters.Add(new Setter(DataGridCell.BorderBrushProperty, Brushes.Transparent));
            c.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(6, 2, 6, 2)));

            return (h, c);
        }

        // =====================================================================
        //  「管理依赖」自定义下拉菜单辅助（Popup + 自定义面板，避免 ContextMenu 白边）
        // =====================================================================

        /// <summary>创建菜单分组标题（固定 accent 色，无 hover）。</summary>
        private TextBlock MakeMenuHeader(string text)
        {
            return new TextBlock
            {
                Text = text,
                Foreground = _accent,
                FontWeight = FontWeights.Bold,
                FontSize = 12.0,
                Padding = new Thickness(8, 5, 8, 3),
                Background = _windowBg,
                TextTrimming = TextTrimming.None,
                TextWrapping = TextWrapping.NoWrap
            };
        }

        /// <summary>创建自定义菜单项：透明背景、hover 行变色、点击后关闭 Popup 并执行 action。</summary>
        private Border MakeMenuItem(string text, Popup popup, Action click = null)
        {
            var tb = new TextBlock
            {
                Text = text,
                Foreground = _textMain,
                FontSize = 12.5,
                Padding = new Thickness(8, 5, 8, 5),
                Background = Brushes.Transparent
            };
            var border = new Border
            {
                Child = tb,
                Background = Brushes.Transparent,
                CornerRadius = new CornerRadius(3),
                Cursor = Cursors.Hand
            };
            border.MouseEnter += (s, e) => border.Background = _rowHover;
            border.MouseLeave += (s, e) => border.Background = Brushes.Transparent;
            // 共 8 个菜单项共用此入口。同步处理器 → 异常直达 Dispatcher（net48 会终止进程）。
            // click 里的动作并不都在 RunInBg 内部（例如「卸载本地依赖」「卸载 WebView2」会先弹 MessageBox，
            // 然后才进后台线程），因此必须在这里整体兜底：先关弹窗保证 UI 状态收敛，再执行动作。
            border.MouseLeftButtonDown += (s, e) =>
            {
                try
                {
                    e.Handled = true;
                    popup.IsOpen = false;
                    click?.Invoke();
                }
                catch (Exception ex)
                {
                    DebugLog.Ignore(ex);
                    try { SetStatus("操作失败: " + ex.Message); }
                    catch { /* 窗口已关闭，忽略 */ }
                }
            };
            return border;
        }

        private FrameworkElement MakeMenuSeparator()
        {
            return new Border
            {
                Height = 1,
                Background = _panelBorder,
                Margin = new Thickness(8, 3, 8, 3)
            };
        }

        // =====================================================================
        //  依赖状态刷新（维护工具页「管理依赖」菜单）
        // =====================================================================

        /// <summary>重入保护：RefreshDepStatus 正在执行（含最长 15s 的 WebView2 初始化）时为 true，连点直接忽略。仅 UI 线程访问。</summary>
        private bool _depRefreshing;

        /// <summary>
        /// 刷新「管理依赖」下拉面板中两种方案的状态文字。
        /// Node 就绪 = 本机或 probes/.tools 存在 node.exe 且 node_modules/playwright 存在。
        /// WebView2 就绪 = 真正创建离屏窗口并 EnsureCoreWebView2Async 初始化成功
        ///   （复用探针实际初始化路径，能识别「Runtime 已装但初始化挂起」这种此前误报就绪的故障）。
        /// </summary>
        private async Task RefreshDepStatus(TextBlock nodeHeader, TextBlock wvHeader, TextBox logBox = null)
        {
            // 重入保护：上一次刷新仍在进行时（WebView2 初始化最长 15s），连点直接忽略，避免并发起多个初始化。
            // 配合 ProbeBrowserHost 的 30s TTL 就绪缓存，首次真实初始化后 30s 内再点基本都会秒回。
            if (_depRefreshing) return;
            _depRefreshing = true;
            try
            {
                if (nodeHeader != null) nodeHeader.Text = "Node + Playwright + Chromium\n（检测中…）";
                if (wvHeader != null) wvHeader.Text = "WebView2 Runtime（系统 Edge）\n（检测中…）";

                var probesDir = ResolveProbesDir();
                var nodeReady = false;
                try
                {
                    nodeReady = IsNodeDepsReady(probesDir).Ready;
                }
                catch (Exception ex) { System.Diagnostics.Debug.WriteLine("IsNodeDepsReady 检测异常: " + ex.Message); }

                // 真实初始化校验：复用 InitAsync（离屏窗口渲染 + EnsureCoreWebView2Async），
                // 给足超时（15s）容纳版本预检与浏览器进程初始化，避免把“可用”误判为“超时未就绪”。
                // 下载百分比进度：经 Dispatcher 回到 UI 线程写入日志框（\r 前缀原地刷新最后一行）。
                Action<int> dlProgress = p =>
                {
                    try { Dispatcher.BeginInvoke(new Action(() => { if (logBox != null) AppendOrReplaceLog(logBox, WebView2ProbeDeps.ProgressLine(p)); })); }
                    catch { /* 窗口已关闭，忽略 */ }
                };
                var (wvReady, wvError) = await ProbeBrowserHost.CheckWebView2ReadyAsync(TimeSpan.FromSeconds(15), null, dlProgress);

                if (nodeHeader != null)
                    nodeHeader.Text = "Node + Playwright + Chromium\n" + (nodeReady ? "（已就绪）" : "（未安装）");
                if (wvHeader != null)
                    wvHeader.Text = "WebView2 Runtime（系统 Edge）\n" + (wvReady ? "（已就绪）" : "（未安装" + (string.IsNullOrEmpty(wvError) ? "" : "：" + wvError) + "）");
            }
            catch (System.Exception ex)
            {
                DebugLog.Ignore(ex);
                // 这里唯一需要补的是"展示层"：CheckWebView2ReadyAsync 是被 await 在 try 内的，
                // 异常确实会被本 catch 吞掉，_depRefreshing 也会由 finally 复位（不会永久卡 true）。
                // 但若不处理，两个分组标题会永远停在"检测中…"，给用户一个与事实不符的假状态。
                // 故异常时把标题改写成明确的失败态，用户再点一次「管理依赖」即可重新检测。
                try
                {
                    if (nodeHeader != null) nodeHeader.Text = "Node + Playwright + Chromium\n（检测未完成，点击重试）";
                    if (wvHeader != null) wvHeader.Text = "WebView2 Runtime（系统 Edge）\n（检测未完成，点击重试）";
                }
                catch { /* 页面已被导航切走，标题控件已脱离视觉树，忽略 */ }
            }
            finally
            {
                _depRefreshing = false;
            }
        }
    }
}
